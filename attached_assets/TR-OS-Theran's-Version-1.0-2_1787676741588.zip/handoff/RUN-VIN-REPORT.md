# How to run the VIN report

Read-only. Four aggregate queries, no row-level data, nothing that identifies a vehicle or a person. Safe to run against production during business hours — it's a few sequential scans on tables of this size.

Source file: `handoff/vin-hygiene-quick.sql`. Pick whichever route below is least friction.

---

## Route A — Replit Database pane (easiest, no terminal)

1. Open the Repl → **Database** tab in the left sidebar.
2. Find the SQL runner / query console.
3. Open `handoff/vin-hygiene-quick.sql` and paste **one query at a time** (the `\echo` lines are psql-only — skip them here).
4. Copy each result table into your reply.

Four pastes. That's it.

---

## Route B — Shell with psql (fastest, one command)

In the Repl Shell:

```bash
psql "$DATABASE_URL" -f handoff/vin-hygiene-quick.sql
```

To capture it to a file you can copy from:

```bash
psql "$DATABASE_URL" -f handoff/vin-hygiene-quick.sql > vin-report.txt 2>&1
cat vin-report.txt
```

If `psql` isn't on the path, try `nix-shell -p postgresql --run 'psql "$DATABASE_URL" -f handoff/vin-hygiene-quick.sql'`, or use Route C.

---

## Route C — Node script (uses the app's own `pg` dependency)

Save this as `vin-report.mjs` in the repo root and run `node vin-report.mjs`. Delete it afterwards — it's a one-off, not something to commit.

```js
import pg from 'pg';
import { readFileSync } from 'fs';

const sql = readFileSync('handoff/vin-hygiene-quick.sql', 'utf8')
  .split('\n').filter(l => !l.trim().startsWith('\\echo')).join('\n');

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
for (const [i, stmt] of sql.split(';').map(s => s.trim()).filter(Boolean).entries()) {
  const { rows } = await client.query(stmt);
  console.log(`\n=== Query ${i + 1} ===`);
  console.table(rows);
}
await client.end();
```

---

## What to send back

The four result tables, pasted raw. No formatting needed. Roughly:

```
Q1: total_inspections | vin_empty | vin_wrong_length | vin_not_upper | ...
Q2: one row per table with rows / blank / needs_normalizing / malformed
Q4: up to three verdict rows with counts
Q5: a single number
```

## What I'll do with it

- **Q1 + Q2** tell me whether this is a write-path bug still producing bad rows or a historical artifact from the localStorage import — which decides whether the fix is urgent or merely necessary.
- **Q4** sizes the human worklist. If most blanks are "recoverable — single match", phase 3 is largely automated. If they're mostly "unrecoverable", we need your §13 decision on what happens to those records before the migration is written.
- **Q5** is the dangerous one. Any number above zero means a naive `UPDATE … SET vin = upper(btrim(vin))` would silently merge distinct records. Above zero, the migration gets a review step; at zero, it's straightforward.

Then I'll write the phase-3 migration: **write-path fix first**, backfill second, index last — with the exact row counts to verify against inside the transaction.

## If something looks wrong

Any error, unexpected column, or a table that doesn't exist — paste the error rather than adjusting the query. A missing table would itself be a finding worth knowing about.

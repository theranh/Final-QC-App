# Handoff — what to do with these files

Four drafts. Nothing here has been applied to either system; I can read the repo but not push to it, so landing these is a Replit-side action.

| File | Lands as | Risk |
|---|---|---|
| `README.md` | replaces `README.md` at repo root | none — documentation |
| `REPLIT_DEPLOYMENT.md` | replaces `REPLIT_DEPLOYMENT.md` at repo root | none — documentation |
| `vehicle-summary-endpoint.md` | `design/vehicle-summary-endpoint.md` (spec to implement later) | none — not code |
| `vin-hygiene.sql` | `scripts/vin-hygiene.sql`, or just run it ad-hoc | none — every statement is a SELECT |

Also copy `ARCHITECTURE_AUDIT.md` (project root here) to `design/ARCHITECTURE_AUDIT.md` in the repo — both new docs reference it by that path.

## Landing sequence (Replit)

```bash
git fetch origin main
git pull --ff-only origin main
# add the four files + design/ARCHITECTURE_AUDIT.md
npm run lint && npm run test && npx tsc --noEmit   # unchanged, but confirms a clean base
git commit -m "docs: correct README and deployment guide to match the actual architecture"
git push origin main
git pull origin main                                # push-then-pull confirmation
```

## Verify while you're in there

Three things I couldn't check from GitHub. All quick, all worth knowing before the next deploy:

1. **`.replit`** — confirm the deployment block is Autoscale (`build: npm run build`, `run: npm run start`) and that no stale `deploymentTarget = "static"` / `publicDir = "dist"` block survives from the earlier architecture. The corrected deployment guide says to check this; it's the one place the stale docs could still cause a real outage.
2. **The admin sync routes** — `/api/quoter/admin/sync` (`server/quoterSyncAdmin.ts:132`), `/api/tracker/admin/sync` and `/api/tracker/admin/sync-counts` (`server/trackerSyncAdmin.ts:33,50`) are registered without a `requireAdmin` guard. Confirm the `QUOTER_SYNC_TOKEN` check inside them is present, compared in constant time, and rate-limited. If it is, note it in a comment so the next reader doesn't re-flag it.
3. **`PRODUCTION_AUDIT.md` and `LIVE_DASHBOARD.md`** — I didn't read either in full, but `PRODUCTION_AUDIT.md` is referenced by the old README as the authority on an architecture that no longer exists. Skim both; if they describe the client-only app, they need the same correction or a "superseded" header.

## Then run the VIN report

`vin-hygiene.sql` against production (read-only). Send me the output of queries 1, 2, 4 and 5 and I'll turn it into the phase-3 migration plan with real numbers instead of estimates. Query 9 is a judgment call that needs you.

## What I need from you

1. **Go/no-go on committing the two corrected docs.** Recommended: go. Highest value, zero risk.
2. **The VIN report output** (queries 1, 2, 4, 5) — turns phase 3 from an estimate into a plan.
3. **Answers to the three verifications above**, particularly `.replit`.
4. **Who owns the Tekion API conversation, and can it start now?** Longest-lead item in the plan; phase 7b can't be scheduled until access, scopes and write permission are known.
5. **§13 of the audit** when you have time — the role × location matrix (5) and photo retention policy (6) are the two that block later phases. The rest can wait.

## What I'd do next, once #1 and #2 land

- Turn the VIN numbers into the phase-3 migration (write-path fix first, then backfill, then index).
- Draft the roles × locations schema change for phase 5, behind a flag defaulting to today's behavior.
- Spec the monorepo move (phase 4) as a pure file-move plan with no logic edits, so it can be reviewed as a diff.

Still holding to read-only on both applications until you say otherwise.

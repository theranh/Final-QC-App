# Step by step — what to do, in order

Two tasks. Task A takes about 10 minutes. Task B takes about 5. Do A first.

Nothing here changes application code, schema, or behavior.

---

# TASK A — Commit the corrected docs to GitHub

## A1. Get the files onto your computer

I've put a download card in the chat labeled **handoff**. Click it. You'll get `handoff.zip`. Unzip it. Inside:

```
README.md                      ← replaces the repo's README.md
REPLIT_DEPLOYMENT.md           ← replaces the repo's REPLIT_DEPLOYMENT.md
vehicle-summary-endpoint.md    ← new file, goes in design/
vin-hygiene.sql                ← full version, for later
vin-hygiene-quick.sql          ← you'll need this in Task B
RUN-VIN-REPORT.md              ← reference
HANDOFF.md                     ← reference
STEP-BY-STEP.md                ← this file
```

You'll also want `ARCHITECTURE_AUDIT.md` — ask me and I'll add it to the download, or open it in this project and copy the text.

## A2. Open the Repl

Open the **Final-QC-App** Repl in Replit. Click the **Shell** tab (not Console — Shell).

## A3. Make sure you're starting from current code

Paste this into the Shell and press Enter:

```bash
git fetch origin main && git pull --ff-only origin main && git status
```

**Expected:** "Already up to date" or a short list of pulled files, then "nothing to commit, working tree clean."

**If it says you have uncommitted changes:** stop and tell me what they are. Don't proceed — we'd be committing someone else's half-finished work along with the docs.

**If `pull --ff-only` fails with "divergent branches":** stop and tell me. That means local and GitHub have both moved and it needs a deliberate resolution.

## A4. Create the design folder

```bash
mkdir -p design
```

## A5. Put the files in place

Drag and drop, in the Replit file tree (left sidebar):

| Drag this file from the unzipped folder | Drop it here | Then |
|---|---|---|
| `README.md` | repo root (the top level, where `package.json` is) | confirm the overwrite |
| `REPLIT_DEPLOYMENT.md` | repo root | confirm the overwrite |
| `vehicle-summary-endpoint.md` | the `design/` folder | — |
| `ARCHITECTURE_AUDIT.md` | the `design/` folder | — |

Replit will ask before overwriting the two existing files. Say yes — that's the point.

**Alternative if drag-and-drop misbehaves:** create each file in the Replit editor (right-click → New file), then copy-paste the contents from the unzipped file.

## A6. Check you changed what you meant to change

```bash
git status
```

**Expected — exactly this, nothing else:**

```
modified:   README.md
modified:   REPLIT_DEPLOYMENT.md
untracked:  design/
```

**If anything else appears** — especially anything under `src/`, `server/`, `shared/`, `attached_assets/`, or a `.env` — stop and tell me. Something got dragged into the wrong place.

## A7. Confirm nothing is broken

```bash
npm run lint && npm run test && npx tsc --noEmit
```

**Expected:** all three pass. We changed only markdown, so a failure here means the base was already broken — worth knowing before you commit, not after. If something fails, paste the output to me and stop.

## A8. Commit and push

```bash
git add README.md REPLIT_DEPLOYMENT.md design/
git commit -m "docs: correct README and deployment guide to match actual architecture

The previous versions described a client-only localStorage app with a Static
deploy target. The app is Express 5 + Postgres + Replit Auth on Autoscale.
Adds design/ARCHITECTURE_AUDIT.md and the vehicle summary endpoint spec."
git push origin main
```

## A9. The push-then-pull confirmation (do not skip)

```bash
git pull origin main && git log --oneline -1 && git rev-parse HEAD origin/main
```

**Expected:** the last two lines print the **same SHA twice**. That's your confirmation local and GitHub agree.

**If the two SHAs differ:** stop and tell me. Someone pushed between your commit and your pull.

## A10. Eyeball it on GitHub

Open `github.com/theranh/Final-QC-App`. The README on the repo home page should now open with "Employee-facing web application for vehicle intake, body quoting, and Final QC inspection" — not the old "No backend — everything is stored locally in the browser."

**Task A done.** The outage trap is gone.

---

# TASK B — Run the VIN report

## B1. Get the SQL file into the Repl

Drag `vin-hygiene-quick.sql` from the unzipped folder into a `handoff/` folder in the Repl (create it if needed). Don't commit this one — it's a scratch file.

## B2. Try the one-command route first

In the Shell:

```bash
psql "$DATABASE_URL" -f handoff/vin-hygiene-quick.sql
```

**If that prints four result tables:** copy everything it printed and paste it to me. **Task B done.**

**If it says `psql: command not found`:** go to B3.

**If it says something else** (connection refused, auth failure, relation does not exist): paste the error to me and stop. Any of those is itself a finding.

## B3. Fallback — the Database pane

1. Left sidebar → **Database** tab.
2. Find the SQL runner / query console.
3. Open `handoff/vin-hygiene-quick.sql` in the editor.
4. There are four queries, separated by the `\echo '=== Q… ==='` comment lines. Copy the text of **one query** at a time — from after an `\echo` line up to and including its `;` — and run it. **Skip the `\echo` lines themselves**; they only work in psql.
5. Copy each result table.

Four queries, four result tables.

## B4. Send them to me

Paste all four tables into the chat, raw. No formatting, no cleanup. Label them Q1–Q4 if it isn't obvious.

They're aggregate counts only — no VINs, no names, nothing identifying.

---

# What to tell me when you're done

1. **Task A:** done, or where it stopped and what it said.
2. **Task B:** the four result tables.
3. **`.replit` check:** open `.replit` in the editor and paste me its `[deployment]` block. I'm looking for whether a stale `deploymentTarget = "static"` line survived from the old architecture. This is the one remaining thing that could still cause a real outage.

Those three, and I can write the phase-3 migration with real numbers instead of estimates.

---

# If you get stuck anywhere

Paste the command you ran and the exact output. Don't work around an error by modifying the command — an unexpected error at any of these steps is information about the system, and I'd rather see it than have it smoothed over.

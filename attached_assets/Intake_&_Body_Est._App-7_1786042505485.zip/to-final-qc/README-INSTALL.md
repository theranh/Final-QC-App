# Final QC — wire in the intake damage quote

Two new files plus three small edits. Nothing existing is redesigned; the panel
uses the app's own `card` / `card-title` / `mono` classes and CSS variables.

## What it does

When the inspector has a full 17-character VIN, Final QC shows what the Intake &
Body Quoter wrote up for that truck: vehicle, stock #, estimator, date, total
hours, and each damage area (panel, damage type, severity, paint). Read-only —
Final QC never writes to the quoter.

The card renders **nothing** when the VIN has no intake quote, so trucks that
skipped the quoter look exactly as they do today.

## New files (already in this folder)

- `server/intakeQuote.ts` — the proxy route, employee-gated, 60s cache, 8s timeout.
- `src/components/IntakeQuoteCard.jsx` — the panel.

Upload both, keeping those paths.

## Edit 1 — register the route

In **`server/routes.ts`**, add the import at the top with the others:

```ts
import { registerIntakeQuoteRoute } from "./intakeQuote";
```

Then inside `registerAppRoutes(app)`, near the other `app.get` calls, add:

```ts
  registerIntakeQuoteRoute(app);
```

## Edit 2 — show it on the new-inspection form

In **`src/components/NewInspectionForm.jsx`**, add the import:

```js
import IntakeQuoteCard from './IntakeQuoteCard';
```

Then place the card right after the **STEP 2 — VEHICLE** card's closing `</div>`,
before the `INSPECTOR` card:

```jsx
        <IntakeQuoteCard vin={vin} />
```

`vin` is already defined at the top of that component.

## Edit 3 (optional) — show it on a saved record

In **`src/components/RecordDetail.jsx`**, same import, then drop
`<IntakeQuoteCard vin={record.vin} />` wherever it reads well in the detail body.
Skip this one if you only want it during the inspection.

## Secrets

In the **Final QC** Repl → Tools → Secrets, add:

| Key | Value |
| --- | --- |
| `FLEET_KEY` | the **same** 64-char hex value used in the quoter Repl |
| `QUOTER_URL` | `https://photo-damage-quoter-copy.replit.app` |

If `FLEET_KEY` doesn't match on both sides, lookups return 401 and the card shows
"Could not reach the quoter."

## Test

1. Restart the Repl.
2. Start a new inspection and enter a VIN that already has a body quote.
3. The card should appear under the vehicle fields once the 17th character lands.

Server-side check from the Shell:

```bash
curl -s "http://localhost:5000/api/intake-quote/YOURTESTVIN"
```

Expect `401` signed out (correct — it's employee-gated). Test through the UI
while signed in instead.

## Then

Commit + push, and Republish so the live QC URL serves it.
